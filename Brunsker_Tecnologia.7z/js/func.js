
// função para carregamento dos dados
function loadBdFile(){
  var xhttp = new XMLHttpRequest();
  
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState==4 && xhttp.status==200) {
      var myArray = xhttp.responseText.split("|");
      drawTable(myArray);
    }    
  };
  xhttp.open("GET", "bdfile.dat", true);
  xhttp.send();
}


// função para inserção dos dados na table
function drawTable(arr){
  for (var i=0; i<arr.length; i++){
    var fulltable = '<tr>';
    var vetor = arr[i].split(",");
    for (var j=0; j<vetor.length; j++){
      fulltable += '<td>'+ vetor[j] +'</td>';
    }
    fulltable += '</tr>';
    fulltable = fulltable.replace(/"/g, "");  // remover aspas duplas da cadeia
    $("#table").find("tbody").append(fulltable);
  }
}


// função para resetar formulário
function formClean(){
  // reset form
  $("#frm").trigger("reset");
  
  window.alert("Salvo com sucesso!"); // mensagem de êxito
}



